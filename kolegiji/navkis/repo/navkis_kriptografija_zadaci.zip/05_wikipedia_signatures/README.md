# Wikipedia Signatures

## Description

https://en.wikipedia.org/w/index.php?title=Digital_signature&oldid=1113936031

Alice signs a message—"Hello Bob!"—by appending to the original message a
version encrypted with her private key. Bob receives both the message and
signature. He uses Alice's public key to verify the authenticity of the
message, i.e. that the encrypted copy, decrypted using the public key, exactly
matches the original message.

`nc <hostname> <port>`

Attachments:
  * [server.py](materials/server.py)

## Solution

[link](solution/README.md)
