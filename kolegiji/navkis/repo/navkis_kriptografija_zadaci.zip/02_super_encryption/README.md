# Super Encryption [400 pts]

There you go, I even encrypted the secret twice to make it unbreakable.
Do you still think it could be stolen, no? yes?

Files:
  - encrypt.py
  - output.txt
