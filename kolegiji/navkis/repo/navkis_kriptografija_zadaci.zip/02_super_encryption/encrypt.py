import hashlib

from Crypto.Cipher import AES
from Crypto.Util.number import bytes_to_long, long_to_bytes, getRandomNBitInteger

SECRET_KEY = str(bin(getRandomNBitInteger(40)))[2:]
FLAG = b"TheBlockTechLtd{REDACTED}"

def bitstring_to_bytearray(bitstring):
    return int(bitstring, 2).to_bytes((len(bitstring) + 7) // 8, 'big')

class SuperEncryptor:
    def __init__(self, key):
        k1 = hashlib.sha256(bitstring_to_bytearray(key[:20])).digest()
        k2 = hashlib.sha256(bitstring_to_bytearray(key[20:])).digest()
        self.c1 = AES.new(k1, AES.MODE_ECB)
        self.c2 = AES.new(k2, AES.MODE_ECB)

    def encrypt(self, message):
        return self.c2.encrypt(self.c1.encrypt(message))

cipher = SuperEncryptor(SECRET_KEY)
with open("output.txt", "w") as out:
    out.write("ciphertext: " + str(bytes_to_long(cipher.encrypt(FLAG))) + "\n")
