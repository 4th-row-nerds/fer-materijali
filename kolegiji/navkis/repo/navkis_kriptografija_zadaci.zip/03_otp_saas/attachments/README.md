We have fully fixed our OTP solution and it is ready for production!

nc localhost 9000
