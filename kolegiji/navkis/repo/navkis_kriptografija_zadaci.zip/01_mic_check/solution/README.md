If you search Z85 with ZeroMQ you will observe that there is something called Ascii85 or Base85. Cyberchef supports this encoding so it's easy to just go to Cyberchef, pick Base85 with Z85 alphabet and decode the string.
```
ibctf{y0-m1c-mic_ch3ck}
```
