#!/usr/bin/env python3

from Crypto.Util.number import *
from random import getrandbits
from sage.all import *
from z3 import *
from pwn import *

flag = b'***********************REDACTED***********************'
FLAG = bytes_to_long(flag)

p = getStrongPrime(512)
q = getStrongPrime(512)
N = p * q
e = 17

o
menu = """ 
[1].CURR STATE
[2].ENCRYPT FLAG
[3].EXIT
"""

class PRNG(object):
    def __init__(self, seed1, seed2):
            self.seed1 = seed1
            self.seed2 = seed2
    
    @staticmethod
    def rotl(x, k):
            return ((x << k) & 0xffffffffffffffff) | (x >> 64 - k)
    
    def next(self):
            s0 = self.seed1
            s1 = self.seed2
            result = (s0 + s1) & 0xffffffffffffffff
            
            s1 ^= s0
            self.seed1 = self.rotl(s0, 55) ^ s1 ^ ((s1 << 14) & 0xffffffffffffffff)
            self.seed2 = self.rotl(s1, 36)
            
            return result

class ZPRNG(object):
    def __init__(self, seed1, seed2):
            self.seed1 = seed1
            self.seed2 = seed2
    
    @staticmethod
    def rotl(x, k):
            return ((x << k) & 0xffffffffffffffff) | (LShR(x,  64 - k))
    
    def next(self):
            s0 = self.seed1
            s1 = self.seed2
            result = (s0 + s1) & 0xffffffffffffffff
            
            s1 ^= s0
            self.seed1 = self.rotl(s0, 55) ^ s1 ^ ((s1 << 14) & 0xffffffffffffffff)
            self.seed2 = self.rotl(s1, 36)
            
            return result

def play():
    a = getrandbits(64)
    b = getrandbits(64)
    g = PRNG(a,b)
     
    print("N : {}".format(N))
    print("e : {}".format(e))
    while True:
        print(menu)
        choice = input("$ ").rstrip().lstrip()
        
        if not choice in ["1","2","3"]:
            print("HIGH AF")
            exit()
            
        if choice == "1":
            print("state for you: {}".format(g.next()))
        
        elif choice == "2": 
            X = g.next()          
            ct = pow(FLAG + X, e, N) 
            print("ENC(flag+next_num): {}".format(ct))
        elif choice == "3":
            exit()
        
def rsa_challege():
    a = getrandbits(64)
    b = getrandbits(64)
    g = PRNG(a,b)
    x1 = g.next()          
    c1 = pow(FLAG + x1, e, N) 
    x2 = g.next()
    c2 = pow(FLAG + x2, e, N) 
    return e, N, x1, x2, c1, c2

def pgcd (a, b):
    if b == 0:
        return a.monic()
    else:
        return pgcd(b, a % b)

def rsa_crack(e, N, x1, x2, c1, c2):
    print(f'{e=}')
    print(f'{N=}')
    print(f'{x1=}')
    print(f'{x2=}')
    print(f'{c1=}')
    print(f'{c2=}')
    R = PolynomialRing(Integers(N), 'x')
    z = R.gen()
    p1 = z**e - c1
    p2 = (z+(x2-x1))**e - c2
    print(p1)
    print(p2)
    g = pgcd(p1, p2)
    print(g)
    m = Integer(-g.coefficients()[0]) - x1
    return long_to_bytes(m)

def prng_challenge():
    a = getrandbits(64)
    b = getrandbits(64)
    g = PRNG(a,b)
    print(f'{a=}')
    print(f'{b=}')
    return [g.next() for _ in range(5)]

def prng_crack(outputs):
    A = BitVec('a', 64)
    B = BitVec('b', 64)
    s = Solver()
    # s.add(A + B == 30)
    # s.add(A < 25)
    # s.add(A ^ B >= 4)
    # s.add(A - B >= 40)    
    # s.check()
    # a = s.model()[A].as_long()
    # b = s.model()[B].as_long()
    # print(f'{a=}')
    # print(f'{b=}')
    # return a, b    
    g = ZPRNG(A, B)
    for x in outputs:
        s.add(g.next() == BitVecVal(x, 64))
    s.check()
    a = s.model()[A].as_long()
    b = s.model()[B].as_long()
    g = PRNG(a, b)
    for x in outputs:
        assert(g.next() == x)
    print(f'{a=}')
    print(f'{b=}')
    return a, b


def crack():
    p = process('./server.py')
    # p = remote('35.200.245.250', 1337)
    p.recvuntil(b'N : ')
    N = int(p.recvline())
    p.recvuntil(b'e : ')
    e = int(p.recvline())
    outputs = []
    for i in range(5):
        p.recvuntil(b'$ ')
        p.sendline(b'1')
        p.recvuntil(b'state for you: ')
        outputs.append(int(p.recvline()))
    print('Collected outputs: ', outputs)
    a, b = prng_crack(outputs)
    g = PRNG(a, b)
    for x in outputs:
        assert(g.next() == x)
    x1 = g.next()
    x2 = g.next()
    p.recvuntil(b'$ ')
    p.sendline(b'2')
    p.recvuntil(b'ENC(flag+next_num): ')
    c1 = int(p.recvline(()))
    p.recvuntil(b'$ ')
    p.sendline(b'2')
    p.recvuntil(b'ENC(flag+next_num): ')
    c2 = int(p.recvline(()))
    print(rsa_crack(e, N, x1, x2, c1, c2))


if __name__ ==  "__main__":
    rsa_crack(*rsa_challege())
    # prng_crack(prng_challenge())
    # crack()
    pass