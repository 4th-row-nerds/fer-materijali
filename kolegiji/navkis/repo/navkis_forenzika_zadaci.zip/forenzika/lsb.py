from PIL import Image # PIL je Python Imaging Library

pixels = list() # lista za pohranu pixela

with Image.open('flag.png') as image: # otvori sliku
    width, height = image.size # budući da je slika kvadratna, visina i širina su iste
    for x in range(width):
        for y in range(height):
            pixels.append(list(image.getpixel((x, y)))) # dodaj pixel u listu

result = '' # rezultat
for pixel in pixels[1337:]: # iteriraj kroz pixel koji ide od 1337 do kraja
    for byte in pixel[:-1]: # uzmi samo RBG vrijednosti bez alfa kanala
        if byte & 1: # ako je zadnji bit 1
            result += '1' # dodaj 1 u rezultat
        else:
            result += '0' # dodaj 0 u rezultat

        if len(result) == 8: # ako je rezultat duljine 8
            if result == '0' * 8: # ako je rezultat 8 nula
                result = '' # resetiraj rezultat
                continue

            char = chr(int(result, 2)) # pretvori rezultat u znak
            print(char, end='') # ispiši znak
            result = '' # resetiraj rezultat
