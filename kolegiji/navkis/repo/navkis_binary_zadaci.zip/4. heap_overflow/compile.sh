gcc -o vuln -no-pie vuln.c 
