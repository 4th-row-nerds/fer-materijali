#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct {
    int age;
    char* name;
} Person;

void win() {
    FILE* in = fopen("flag.txt", "r");
    char flag[64];
    fscanf(in, "%63s", flag);
    puts(flag);
}

int main() {
    puts("Welcome to my program");
    printf("Libc leak: %p\n", system);
    Person* p1 = (Person*)malloc(sizeof(Person));
    p1->age = 18;
    p1->name = (char*)malloc(16);


    Person* p2 = (Person*)malloc(sizeof(Person));
    p2->age = 21;
    p2->name = (char*)malloc(16);

    fgets(p1->name, 64, stdin);
    fgets(p2->name, 64, stdin);

    printf("Goodbye both of you!");

    return 0;
}
