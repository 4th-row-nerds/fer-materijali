gcc -o vuln --no-stack-protector -fno-pie -z execstack --static vuln.c

