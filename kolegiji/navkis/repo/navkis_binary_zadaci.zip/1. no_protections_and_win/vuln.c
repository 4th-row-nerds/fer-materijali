#include <stdio.h> 

void win() {
    FILE* file = fopen("flag.txt", "r");
    char flag[64];
    fgets(flag, 64, file);
    puts(flag);
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    char buf[16];
    printf("Enter your name: ");
    fgets(buf, 128, stdin);
    printf("Welcome %s\n", buf);

    return 0;
}
