#include <stdio.h> 
#include <stdlib.h>

void __gadgets() {
    __asm__("pop %rdi\n\t"
            "ret\n\t");
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    char buf[16];
    puts("Enter your name: ");
    fgets(buf, 128, stdin);
    printf("Welcome %s\n", buf);

    return 0;
}
