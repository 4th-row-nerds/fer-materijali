gcc -o vuln --no-stack-protector -no-pie vuln.c 
