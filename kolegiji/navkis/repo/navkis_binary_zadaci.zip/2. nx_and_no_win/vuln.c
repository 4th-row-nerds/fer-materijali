#include <stdio.h> 
#include <stdlib.h>

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    char buf[16];
    printf("Enter your name: ");
    fgets(buf, 128, stdin);
    printf("Welcome %s\n", buf);

    return 0;
}
