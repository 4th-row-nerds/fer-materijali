gcc -o vuln --no-stack-protector -no-pie -static -Wl,--undefined=system vuln.c 
